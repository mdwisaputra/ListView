package com.example.listviewicon

class Model (val title:String, val description:String, val img:Int) {
}